using Terraria.ModLoader;

namespace ButterflySword
{
	class ButterflySword : Mod
	{
		public ButterflySword()
		{
		}
	}
}
